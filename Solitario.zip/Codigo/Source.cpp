#include <iostream>
#include "List.h"
#include "carta.h"
#include "run.h"
int main() {
	juego* a = new juego();
	run(0, a);
	return 0;
}

