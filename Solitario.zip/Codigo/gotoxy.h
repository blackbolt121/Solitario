#pragma once
#include <iostream>
#include <Windows.h>
void gotoXY(int x, int y);
