#pragma once
#include "juego.h"
#include "gotoxy.h"
void run(int x, juego *&a);
void operaciones(int x, juego *&a);
void toLowerCase(std::string&);
int menu();
